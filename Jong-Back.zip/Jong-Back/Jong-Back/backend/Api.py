from fastapi import FastAPI, HTTPException, UploadFile, File
from pydantic import BaseModel
import shutil
import os
import json
import asyncio

app = FastAPI()

# 로그인 및 상태 전역 변수
STUDENT_ID = None
PASSWORD = None
TASK_TYPE = 0
PROMPT_TEXT = None
PROMPT_EVENT = asyncio.Event()
PROMPT_EVENT.set()  # no pending prompt initially
LOGIN_EVENT = asyncio.Event()
LOGIN_EVENT.set()   # no pending login initially

# 로그인 요청 모델
class LoginRequest(BaseModel):
    student_id: str
    password: str

@app.post("/login")
async def login(request: LoginRequest):
    global STUDENT_ID, PASSWORD, TASK_TYPE, LOGIN_EVENT

    # 이미 대기 중인 로그인 요청이 있으면 거절
    if not LOGIN_EVENT.is_set():
        raise HTTPException(status_code=409, detail="이미 대기 중인 로그인 요청이 있습니다.")

    STUDENT_ID = request.student_id
    PASSWORD = request.password
    TASK_TYPE = 1
    LOGIN_EVENT.clear()

    # /command가 로그인 테스크를 가져갈 때까지 대기 (타임아웃 포함)
    try:
        await asyncio.wait_for(LOGIN_EVENT.wait(), timeout=30.0)
    except asyncio.TimeoutError:
        # 타임아웃 시 상태 초기화
        TASK_TYPE = 0
        LOGIN_EVENT.set()
        raise HTTPException(status_code=504, detail="command가 로그인 요청을 가져가지 않아 타임아웃되었습니다.")

    # /command에서 로그인 테스크를 가져간 것이 확인된 후 성공 응답
    return {
        "ok": True,
        "student_id": STUDENT_ID,
        "message": "로그인 요청이 command로 전달되었습니다."
    }

class PromptRequest(BaseModel):
    text: str

@app.post("/prompt")
async def prompt(request: PromptRequest):
    global PROMPT_TEXT, PROMPT_EVENT, TASK_TYPE

    # 이미 대기 중인 프롬프트가 있으면 거절
    if not PROMPT_EVENT.is_set():
        raise HTTPException(status_code=409, detail="이미 대기 중인 프롬프트가 있습니다.")

    # 새 프롬프트 저장
    PROMPT_TEXT = request.text
    TASK_TYPE = 2
    PROMPT_EVENT.clear()

    # /command가 프롬프트를 가져갈 때까지 대기 (타임아웃 포함)
    try:
        await asyncio.wait_for(PROMPT_EVENT.wait(), timeout=30.0)
    except asyncio.TimeoutError:
        # 타임아웃 시 상태 초기화
        PROMPT_TEXT = None
        PROMPT_EVENT.set()
        raise HTTPException(status_code=504, detail="action이 완료되지 않아 타임아웃되었습니다.")

    # /command에서 프롬프트를 가져간 것이 확인된 후 성공 응답
    return {
        "ok": True,
        "prompt_text": request.text,
        "message": "프롬프트가 command로 전달되었습니다."
    }

class StateData(BaseModel):
    data: dict

@app.post("/state")
async def save_state(request: StateData):
    global TASK_TYPE, PROMPT_EVENT
    save_path = os.path.join(os.path.dirname(__file__), "state.json")
    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(request.data, f, ensure_ascii=False, indent=2)
    TASK_TYPE = 3

    # /action에서 전체 플로우가 끝날 때까지 대기 (타임아웃 포함)
    try:
        await asyncio.wait_for(PROMPT_EVENT.wait(), timeout=60.0)
    except asyncio.TimeoutError:
        TASK_TYPE = 0
        PROMPT_EVENT.set()
        raise HTTPException(status_code=504, detail="action이 완료되지 않아 타임아웃되었습니다.")

    return {
        "ok": True,
        "message": "state.json 저장 및 action 실행이 완료되었습니다.",
        "path": save_path
    }

from fastapi.responses import JSONResponse

@app.get("/command")
async def command():
    global PROMPT_TEXT, PROMPT_EVENT, TASK_TYPE, LOGIN_EVENT, STUDENT_ID, PASSWORD
    # If no pending task
    if TASK_TYPE == 0:
        return {
            "has_task": False,
            "message": "대기 중인 테스크가 없습니다."
        }

    current_type = TASK_TYPE

    # There is some task
    resp = {
        "has_task": True,
        "task_type": current_type,
    }

    if current_type == 1:
        # login task
        resp["type"] = "login"
        resp["student_id"] = STUDENT_ID
        resp["password"] = PASSWORD
        # 로그인 테스크 소비를 알림
        LOGIN_EVENT.set()
        # 로그인은 여기서 바로 소모되므로 타입 리셋
        TASK_TYPE = 0

    elif current_type == 2:
        resp["type"] = "state"

    elif current_type == 3:
        # state task
        resp["type"] = "action"

    return resp

@app.get("/action")
def get_action():
    global TASK_TYPE, PROMPT_EVENT
    state_path = os.path.join(os.path.dirname(__file__), "state.json")
    if not os.path.exists(state_path):
        raise HTTPException(status_code=404, detail="state.json 파일이 존재하지 않습니다.")
    with open(state_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # action까지 실행이 완료되었으므로 타입을 0으로 리셋하고,
    # 기다리는 /prompt 와 /state 를 깨운다.
    TASK_TYPE = 0
    PROMPT_EVENT.set()

    return JSONResponse(content=data)
